chrome.action.onClicked.addListener((tab) => {
  // restricted URL check
  if (!tab.url || tab.url.startsWith('chrome://') || tab.url.startsWith('edge://') || tab.url.startsWith('about:')) {
    return;
  }

  if (tab.id) {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        window.scrollTo(0, 0);
      }
    }).catch(err => {
      // Catch other potential errors to avoid unhandled promise rejections
      console.log('Script injection failed: ', err);
    });
  }
});
