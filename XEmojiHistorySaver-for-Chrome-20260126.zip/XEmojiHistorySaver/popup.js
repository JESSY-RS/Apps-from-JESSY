document.addEventListener('DOMContentLoaded', async () => {
    const grid = document.getElementById('emoji-grid');
    const statusMsg = document.getElementById('status-message');

    // Load history
    const history = await StorageManager.getHistory();

    if (history.length === 0) {
        // Show "No History" in Grid instead of footer to prevent layout shift
        grid.innerHTML = '<div style="grid-column: 1 / -1; text-align: left; color: gray; font-size: 14px; padding: 15px 10px 10px 10px;">履歴なし</div>';
        statusMsg.textContent = "";
    } else {
        history.forEach(emoji => {
            const div = document.createElement('div');
            div.className = 'emoji-item';
            div.textContent = emoji;
            div.addEventListener('click', async () => {
                // 1. Copy to clipboard
                await navigator.clipboard.writeText(emoji);
                statusMsg.textContent = `Inserted: ${emoji}`;

                // 2. Insert into active page
                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
                if (tab) {
                    chrome.tabs.sendMessage(tab.id, {
                        action: 'insertEmoji',
                        emoji: emoji
                    }).catch(err => {
                        console.log('Message failed:', err);
                    });
                }

                setTimeout(() => {
                    statusMsg.textContent = '';
                }, 2000);
            });

            // Right click to remove
            div.addEventListener('contextmenu', async (e) => {
                e.preventDefault();
                if (confirm(`${emoji} を履歴から削除しますか？`)) {
                    await StorageManager.removeEmoji(emoji);
                    div.remove();
                    if (grid.children.length === 0) {
                        statusMsg.textContent = "履歴なし";
                        statusMsg.style.color = "gray";
                        statusMsg.style.fontSize = "14px";
                        statusMsg.style.padding = "5px";
                    }
                }
            });

            grid.appendChild(div);
        });
    }

    // --- Settings UI Logic ---
    const settingsIcon = document.getElementById('settings-icon');
    const settingsPanel = document.getElementById('settings-panel');
    const inpTop = document.getElementById('inp-top');
    const inpRight = document.getElementById('inp-right');
    const inpOverlayTop = document.getElementById('overlay-top');
    const inpOverlayRight = document.getElementById('overlay-right');
    const settingsStatus = document.getElementById('settings-status');

    const DEFAULTS = {
        top: 1.5,
        right: 15,
        overlay_top: 61.5,
        overlay_right: 15
    };

    settingsIcon.addEventListener('click', () => {
        if (settingsPanel.style.display === 'none') {
            settingsPanel.style.display = 'block';
            loadPositions();
        } else {
            settingsPanel.style.display = 'none';
        }
    });

    // Toggle Preview: Overlay
    // Toggle Preview: Overlay - REMOVED (Always preview on input change)

    function loadPositions() {
        chrome.storage.local.get(['fab_pos_top', 'fab_pos_right', 'overlay_pos_top', 'overlay_pos_right'], (res) => {
            // FAB defaults
            const currentTop = res.fab_pos_top !== undefined ? res.fab_pos_top : DEFAULTS.top;
            const currentRight = res.fab_pos_right !== undefined ? res.fab_pos_right : DEFAULTS.right;
            inpTop.value = parseFloat(currentTop).toFixed(1);
            inpRight.value = parseFloat(currentRight).toFixed(1);

            // Overlay defaults
            const currentOverlayTop = res.overlay_pos_top !== undefined ? res.overlay_pos_top : DEFAULTS.overlay_top;
            const currentOverlayRight = res.overlay_pos_right !== undefined ? res.overlay_pos_right : DEFAULTS.overlay_right;
            inpOverlayTop.value = parseFloat(currentOverlayTop).toFixed(1);
            inpOverlayRight.value = parseFloat(currentOverlayRight).toFixed(1);

            settingsStatus.textContent = '※数値を変えるとプレビュー表示されます';
        });

        // Sync Checkbox State from Content Script
        // Sync Checkbox State - REMOVED
    }

    // Preview FAB
    async function sendFabPreview() {
        // settingsStatus.textContent = 'プレビュー中(FAB)...';
        const top = inpTop.value !== '' ? parseFloat(inpTop.value) : DEFAULTS.top;
        const right = inpRight.value !== '' ? parseFloat(inpRight.value) : DEFAULTS.right;

        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab) {
            chrome.tabs.sendMessage(tab.id, {
                action: 'preview_fab_position',
                top: top,
                right: right
            }).catch(() => { });
        }
    }

    // Preview Overlay
    async function sendOverlayPreview() {
        // settingsStatus.textContent = 'プレビュー中(Popup)...';
        const overlayTop = inpOverlayTop.value !== '' ? parseFloat(inpOverlayTop.value) : DEFAULTS.overlay_top;
        const overlayRight = inpOverlayRight.value !== '' ? parseFloat(inpOverlayRight.value) : DEFAULTS.overlay_right;

        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab) {
            chrome.tabs.sendMessage(tab.id, {
                action: 'preview_overlay_position',
                overlay_top: overlayTop,
                overlay_right: overlayRight
            }).catch(() => { });
        }
    }

    // Handle Input for FAB
    function handleFabInput(e) {
        if (!e.inputType) {
            const val = parseFloat(this.value);
            if (!isNaN(val)) this.value = val.toFixed(1);
        }
        sendFabPreview();
    }

    // Handle Input for Overlay
    function handleOverlayInput(e) {
        if (!e.inputType) {
            const val = parseFloat(this.value);
            if (!isNaN(val)) this.value = val.toFixed(1);
        }
        sendOverlayPreview();
    }

    inpTop.addEventListener('input', handleFabInput);
    inpRight.addEventListener('input', handleFabInput);
    inpOverlayTop.addEventListener('input', handleOverlayInput);
    inpOverlayRight.addEventListener('input', handleOverlayInput);

    // Auto-select on focus
    inpTop.addEventListener('focus', function () { this.select(); });
    inpRight.addEventListener('focus', function () { this.select(); });
    inpOverlayTop.addEventListener('focus', function () { this.select(); });
    inpOverlayRight.addEventListener('focus', function () { this.select(); });

    // Format on blur (restore .0 if integer)
    function formatBlur() {
        if (this.value !== '') this.value = parseFloat(this.value).toFixed(1);
    }
    inpTop.addEventListener('blur', formatBlur);
    inpRight.addEventListener('blur', formatBlur);
    inpOverlayTop.addEventListener('blur', formatBlur);
    inpOverlayRight.addEventListener('blur', formatBlur);

    // Save FAB
    document.getElementById('save-fab').addEventListener('click', () => {
        const top = inpTop.value !== '' ? parseFloat(inpTop.value) : DEFAULTS.top;
        const right = inpRight.value !== '' ? parseFloat(inpRight.value) : DEFAULTS.right;

        chrome.storage.local.set({
            fab_pos_top: top,
            fab_pos_right: right
        }, () => {
            settingsStatus.textContent = 'ボタン位置を保存しました';
            setTimeout(() => settingsStatus.textContent = '※数値を変えるとプレビュー表示されます', 2000);
        });
    });

    // Reset FAB
    document.getElementById('reset-fab').addEventListener('click', () => {
        if (confirm('ボタン位置を初期値に戻してもよろしいですか？')) {
            const config = {
                fab_pos_top: DEFAULTS.top,
                fab_pos_right: DEFAULTS.right
            };
            chrome.storage.local.set(config, () => {
                inpTop.value = DEFAULTS.top.toFixed(1);
                inpRight.value = DEFAULTS.right.toFixed(1);
                settingsStatus.textContent = 'リセットしました';
                setTimeout(() => settingsStatus.textContent = '※数値を変えるとプレビュー表示されます', 2000);
                sendFabPreview();
            });
        }
    });

    // Save Overlay
    document.getElementById('save-overlay').addEventListener('click', () => {
        const overlayTop = inpOverlayTop.value !== '' ? parseFloat(inpOverlayTop.value) : DEFAULTS.overlay_top;
        const overlayRight = inpOverlayRight.value !== '' ? parseFloat(inpOverlayRight.value) : DEFAULTS.overlay_right;

        chrome.storage.local.set({
            overlay_pos_top: overlayTop,
            overlay_pos_right: overlayRight
        }, () => {
            settingsStatus.textContent = 'ポップアップ位置を保存しました';
            setTimeout(() => settingsStatus.textContent = '※数値を変えるとプレビュー表示されます', 2000);
        });
    });

    // Reset Overlay
    document.getElementById('reset-overlay').addEventListener('click', () => {
        if (confirm('ポップアップ位置を初期値に戻してもよろしいですか？')) {
            const config = {
                overlay_pos_top: DEFAULTS.overlay_top,
                overlay_pos_right: DEFAULTS.overlay_right
            };
            chrome.storage.local.set(config, () => {
                inpOverlayTop.value = DEFAULTS.overlay_top.toFixed(1);
                inpOverlayRight.value = DEFAULTS.overlay_right.toFixed(1);
                settingsStatus.textContent = 'リセットしました';
                setTimeout(() => settingsStatus.textContent = '※数値を変えるとプレビュー表示されます', 2000);
                sendOverlayPreview();
            });
        }
    });

    // Delete All History
    const deleteAllBtn = document.getElementById('delete-all');
    deleteAllBtn.addEventListener('click', async () => {
        if (confirm('履歴をすべて削除してもよろしいですか？')) {
            await StorageManager.clearHistory();
            grid.innerHTML = '<div style="grid-column: 1 / -1; text-align: left; color: gray; font-size: 14px; padding: 15px 10px 10px 10px;">履歴なし</div>';
            statusMsg.textContent = "";
        }
    });
});
