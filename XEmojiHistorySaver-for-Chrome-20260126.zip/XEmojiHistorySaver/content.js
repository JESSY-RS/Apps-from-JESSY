/**
 * X Emoji History Saver - Content Script
 * v5: No-Polling + Global Error Suppression
 */

const EMOJI_REGEX = /\p{Emoji_Presentation}|\p{Extended_Pictographic}/gu;
let mutationObserver = null;
let inputListener = null;

// --- Global Error Suppression ---
// This acts as a final shield against the "Extension context invalidated" noise.
window.addEventListener('error', function (e) {
    if (e.message && e.message.includes('Extension context invalidated')) {
        e.preventDefault();
        e.stopPropagation();
        cleanup();
        return true;
    }
}, true);

// --- Context Validity Checker & Cleanup ---
function isValidContext() {
    try {
        // Accessing chrome.runtime.id is the standard check
        // If chrome.runtime is undefined (nuked), this throws or returns false
        if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.id) {
            return false;
        }
        return true;
    } catch (e) {
        return false;
    }
}

function cleanup() {
    if (mutationObserver) mutationObserver.disconnect();
    if (inputListener) document.removeEventListener('input', inputListener, true);
    mutationObserver = null;
    inputListener = null;
}

// --- Logic ---

function getActiveEditor() {
    // DOM access is safe from "Extension context invalidated"
    // (Only chrome.* APIs trigger it)
    const active = document.activeElement;
    if (active && (active.tagName === 'TEXTAREA' || active.isContentEditable)) {
        return active;
    }
    return document.querySelector('[data-testid="tweetTextarea_0"]') ||
        document.querySelector('[data-testid="dmComposerTextInput"]');
}

function debounce(func, wait) {
    let timeout;
    return function (...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => {
            if (!isValidContext()) {
                cleanup();
                return;
            }
            func(...args);
        }, wait);
    };
}

const processInput = debounce((text) => {
    if (!text) return;
    const emojis = text.match(EMOJI_REGEX);
    if (emojis && emojis.length > 0) {
        saveEmojis(emojis);
    }
}, 500);

function saveEmojis(emojiList) {
    if (!isValidContext()) {
        cleanup();
        return;
    }

    try {
        chrome.storage.local.get(['emoji_history'], (result) => {
            if (chrome.runtime.lastError || !isValidContext()) return;

            let history = result.emoji_history || [];
            const newEmojis = [...new Set(emojiList)];

            let changed = false;
            newEmojis.forEach(char => {
                if (history[0] !== char) {
                    history = history.filter(e => e !== char);
                    history.unshift(char);
                    changed = true;
                }
            });

            if (changed) {
                history = history.slice(0, 100);
                chrome.storage.local.set({ emoji_history: history }, () => {
                    // Suppress checks here
                });
            }
        });
    } catch (e) {
        cleanup();
    }
}

// --- Listeners ---

// 1. Input Event
inputListener = (e) => {
    if (!isValidContext()) {
        cleanup();
        return;
    }

    const target = e.target;
    // Simplified check
    if (target.tagName === 'TEXTAREA' || target.tagName === 'INPUT' || target.isContentEditable) {
        processInput(target.innerText || target.value || '');
    }
};
document.addEventListener('input', inputListener, true);

// 2. MutationObserver
mutationObserver = new MutationObserver((mutations) => {
    if (!isValidContext()) {
        cleanup();
        return;
    }

    const editor = getActiveEditor();
    if (editor) {
        processInput(editor.innerText || editor.value || '');
    }
});

mutationObserver.observe(document.body, {
    childList: true,
    characterData: true,
    subtree: true
});

// 3. Message Listener
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (!isValidContext()) return;

    if (request.action === 'insertEmoji' && request.emoji) {
        const editor = getActiveEditor();
        if (editor) {
            editor.focus();
            const success = document.execCommand('insertText', false, request.emoji);
            if (!success) {
                editor.innerText += request.emoji;
                editor.dispatchEvent(new Event('input', { bubbles: true }));
            }
        }
    }
});

console.log("X Emoji History Saver: Content script loaded (v7 - Tab clean required).");
